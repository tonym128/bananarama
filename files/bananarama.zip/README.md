# bananarama
![Bananarama Logo](files/bananarama.png)

## Banana Runner for Arduboy Banana Game Jam

Author  - Tony Mamacos

Version - 1.0

URL     - https://community.arduboy.com/t/bananarama/12666

Source  - https://github.com/tonym128/bananarama

Game Jam - https://community.arduboy.com/t/arduboy-banana-jam/12645

# Gameplay

![Bananarama Logo](files/gameplay.gif)

[Click to play Game](https://tiberiusbrown.github.io/Ardens/player.html?blah=https://github.com/tonym128/bananarama/raw/refs/heads/main/files/bananarama.arduboy)

# Special Thanks

tiberiusbrown for ABC and Arderns - https://github.com/tiberiusbrown/abc , https://github.com/tiberiusbrown/Ardens

KabGames for the button pack https://kaboff.itch.io/pixel-buttons-pack
